
# School Management System - Frontend (Next.js + Chakra UI)

## Quick start
1. `cd frontend`
2. `npm install`
3. `npm run dev`
4. Open http://localhost:3000

The frontend expects a PHP backend accessible at `/api/*` relative paths.
See the backend README for setup instructions.
